﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace first
{
    public abstract class person
    {
        string name;
        int age;
        int id;
        public person() { }
        public person(string name, int age, int id)
        {
            this.name = name;
            this.age = age;
            this.id = id;
        }
    }
}
