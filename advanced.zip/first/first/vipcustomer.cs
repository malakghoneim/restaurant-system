﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace first
{
    public class vipcustomer:customer
    {
        string promocode;
        public vipcustomer() { }
        public vipcustomer(string name, int age, int id,string promocode):base(name,age,id)
        {
            this.promocode = promocode;
            
        }
        public override double orderfood(menuitems item, int quantity)
        {
            return (item.price) * quantity*0.2;
        }
    }
}
