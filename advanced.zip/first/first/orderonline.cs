﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace first
{
    public partial class orderonline : Form
    {
        double total = 0;
        public orderonline()
        {
            InitializeComponent();
        }

        private void orderonline_Load(object sender, EventArgs e)
        {
            start.item[0] = new menuitems("pizza", 10, 20);
            start.item[1] = new menuitems("pasta", 0, 10);
            start.item[2] = new menuitems("salad", 8, 25);
            if (start.item[0].count > 0)
            {
                comboBox1.Items.Add("pizza");
            }
            if (start.item[1].count > 0)
                comboBox1.Items.Add("pasta");
            if (start.item[2].count > 0)
                comboBox1.Items.Add("salad");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selected = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
            int count = Convert.ToInt32(numericUpDown1.Value);
            
            if (start.allcustomers[start.counter -1] is normalcustomer)
            {
                
               
                if (selected == "pizza")
                {
                    total = total + start.allcustomers[start.counter-1].orderfood(start.item[0], count);
                    
                    start.item[0].count--;
                }
                else if( selected=="pasta")
                {
                    total = total + start.allcustomers[start.counter - 1].orderfood(start.item[1], count);
                    start.item[1].count--;
                }
                else if (selected == "salad")
                {
                    total = total + start.allcustomers[start.counter - 1].orderfood(start.item[2], count);
                    start.item[2].count--;
                }
                label2.Text = total.ToString();
            }
            else if(start.allcustomers[start.counter - 1] is vipcustomer)
            {
                
                if (selected == "pizza")
                {
                    total = total + start.allcustomers[start.counter - 1].orderfood(start.item[0], count);
                    start.item[0].count--;
                }
                else if (selected == "pasta")
                {
                    total = total + start.allcustomers[start.counter - 1].orderfood(start.item[1], count);
                    start.item[1].count--;
                }
                else if (selected == "salad")
                {
                    total = total + start.allcustomers[start.counter - 1].orderfood(start.item[2], count);
                    start.item[2].count--;
                }
                label2.Text = total.ToString();
            }
           
            
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
