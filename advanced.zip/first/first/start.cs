﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace first
{
    public partial class start : Form
    {
        public start()
        {
            InitializeComponent();
        }
        public static customer[] allcustomers = new customer[2000];
        public static chef[] chefs = new chef[10];
        public static menuitems[] item = new menuitems[3];
        public static int counter = 0;
        public static int chefcounter = 0;
        public static ingredients[] ingredients = new ingredients[10];

        private void button1_Click(object sender, EventArgs e)
        {
            
            new customerform().ShowDialog();
            this.Close();

        }

        private void start_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            new chefform().ShowDialog();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
